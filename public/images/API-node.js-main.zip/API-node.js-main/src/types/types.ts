export interface JwtPayload {
    _id: string;
}